-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.5.7-MariaDB-log - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for homesyslite
CREATE DATABASE IF NOT EXISTS `homesyslite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `homesyslite`;

-- Dumping structure for table homesyslite.adminuser
CREATE TABLE IF NOT EXISTS `adminuser` (
  `Id` varchar(36) NOT NULL,
  `Username` varchar(16) NOT NULL,
  `Password` varchar(12) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.cast
CREATE TABLE IF NOT EXISTS `cast` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(128) NOT NULL,
  `MovieName` varchar(128) DEFAULT NULL,
  `PorthuId` bigint(20) NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `PorthuId` (`PorthuId`),
  KEY `Modified` (`Modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.channel
CREATE TABLE IF NOT EXISTS `channel` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(128) NOT NULL,
  `Url` varchar(128) DEFAULT NULL,
  `Logo` mediumblob DEFAULT NULL,
  `Radio` tinyint(1) NOT NULL DEFAULT 0,
  `HasProgram` tinyint(1) NOT NULL DEFAULT 0,
  `PorthuId` bigint(20) NOT NULL DEFAULT 0,
  `PorthuName` varchar(128) DEFAULT NULL,
  `Priority` int(11) DEFAULT NULL,
  `ItemId` bigint(20) DEFAULT NULL,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Name` (`Name`),
  KEY `PorthuId` (`PorthuId`),
  KEY `Modified` (`Modified`),
  KEY `Radio` (`Radio`),
  KEY `HasProgram` (`HasProgram`),
  KEY `Priority` (`Priority`)
) ENGINE=InnoDB AUTO_INCREMENT=1430 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.channelalias
CREATE TABLE IF NOT EXISTS `channelalias` (
  `ChannelId` bigint(20) NOT NULL,
  `Name` varchar(128) NOT NULL,
  KEY `ChannelId` (`ChannelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.channelregion
CREATE TABLE IF NOT EXISTS `channelregion` (
  `ChannelId` bigint(20) NOT NULL,
  `RegionId` varchar(3) NOT NULL,
  UNIQUE KEY `ChannelId` (`ChannelId`,`RegionId`),
  KEY `RegionId` (`RegionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.channelunknown
CREATE TABLE IF NOT EXISTS `channelunknown` (
  `Name` varchar(128) NOT NULL,
  `UserId` varchar(36) DEFAULT NULL,
  `RegionId` varchar(3) DEFAULT NULL,
  `At` timestamp NOT NULL DEFAULT current_timestamp(),
  UNIQUE KEY `Name` (`Name`,`UserId`),
  KEY `UserId` (`UserId`),
  KEY `RegionId` (`RegionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.denied_ip
CREATE TABLE IF NOT EXISTS `denied_ip` (
  `IP` varchar(15) NOT NULL,
  `Occur` smallint(5) unsigned NOT NULL DEFAULT 0,
  `IsDev` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `LastTime` datetime NOT NULL DEFAULT current_timestamp(),
  `FirstTime` datetime DEFAULT NULL,
  UNIQUE KEY `IP` (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.device
CREATE TABLE IF NOT EXISTS `device` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Brand` varchar(64) NOT NULL,
  `Model` varchar(192) DEFAULT NULL,
  `Serial` varchar(128) DEFAULT NULL,
  `System` varchar(64) DEFAULT NULL,
  `NetworkId` varchar(16) DEFAULT NULL,
  `InvalidDeviceUserId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Brand` (`Brand`,`Model`,`Serial`),
  KEY `InvalidDeviceUserId` (`InvalidDeviceUserId`),
  KEY `System` (`System`)
) ENGINE=InnoDB AUTO_INCREMENT=71216 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for view homesyslite.devicelist
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `devicelist` (
	`userid` VARCHAR(36) NOT NULL COLLATE 'utf8_general_ci',
	`username` VARCHAR(32) NOT NULL COLLATE 'utf8_general_ci',
	`deviceid` BIGINT(20) NOT NULL,
	`system` VARCHAR(64) NULL COLLATE 'utf8_general_ci',
	`brand` VARCHAR(64) NOT NULL COLLATE 'utf8_general_ci',
	`model` VARCHAR(192) NULL COLLATE 'utf8_general_ci',
	`serial` VARCHAR(128) NULL COLLATE 'utf8_general_ci',
	`firstseen` DATETIME NOT NULL,
	`lastseen` DATETIME NOT NULL,
	`vodauthat` DATETIME NULL
) ENGINE=MyISAM;

-- Dumping structure for table homesyslite.dvbcategory
CREATE TABLE IF NOT EXISTS `dvbcategory` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(128) NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Modified` (`Modified`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.episode
CREATE TABLE IF NOT EXISTS `episode` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MovieId` bigint(20) NOT NULL,
  `Title` varchar(192) NOT NULL,
  `Description` text DEFAULT NULL,
  `EpisodeNumber` smallint(6) NOT NULL DEFAULT 0,
  `PorthuId` bigint(20) NOT NULL DEFAULT 0,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `MovieId` (`MovieId`),
  KEY `EpisodeNumber` (`EpisodeNumber`),
  KEY `PorthuId` (`PorthuId`),
  KEY `Modified` (`Modified`),
  FULLTEXT KEY `TitleDescription` (`Title`,`Description`)
) ENGINE=InnoDB AUTO_INCREMENT=39728722 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.episodecast
CREATE TABLE IF NOT EXISTS `episodecast` (
  `EpisodeId` bigint(20) NOT NULL,
  `CastId` bigint(20) NOT NULL,
  `RoleId` tinyint(4) NOT NULL,
  `MovieName` varchar(128) DEFAULT NULL,
  KEY `EpisodeId` (`EpisodeId`),
  KEY `CastId` (`CastId`),
  KEY `RoleId` (`RoleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.machine
CREATE TABLE IF NOT EXISTS `machine` (
  `Id` varchar(36) NOT NULL,
  `UserId` varchar(36) NOT NULL,
  `Name` varchar(64) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `UserId` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.movie
CREATE TABLE IF NOT EXISTS `movie` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MovieTypeId` bigint(20) NOT NULL,
  `DVBCategoryId` bigint(20) NOT NULL,
  `Title` varchar(192) NOT NULL,
  `Description` text DEFAULT NULL,
  `Rating` tinyint(4) NOT NULL DEFAULT 0,
  `Year` smallint(6) NOT NULL DEFAULT 0,
  `EpisodeCount` smallint(6) NOT NULL DEFAULT 0,
  `PorthuId` bigint(20) NOT NULL DEFAULT 0,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `PictureUrl` varchar(128) DEFAULT NULL,
  `PictureDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `MovieTypeId` (`MovieTypeId`),
  KEY `DVBCategoryId` (`DVBCategoryId`),
  KEY `Year` (`Year`),
  KEY `Rating` (`Rating`),
  KEY `PorthuId` (`PorthuId`),
  KEY `Modified` (`Modified`),
  FULLTEXT KEY `TitleDescription` (`Title`,`Description`)
) ENGINE=InnoDB AUTO_INCREMENT=21270234 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.moviesearch
CREATE TABLE IF NOT EXISTS `moviesearch` (
  `Str` varchar(128) NOT NULL,
  `At` datetime NOT NULL,
  UNIQUE KEY `Str` (`Str`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.movietype
CREATE TABLE IF NOT EXISTS `movietype` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `NameShort` varchar(64) NOT NULL,
  `NameLong` varchar(128) NOT NULL,
  `GroupId` bigint(20) NOT NULL DEFAULT 0,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Modified` (`Modified`)
) ENGINE=InnoDB AUTO_INCREMENT=2063 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.movietypegroup
CREATE TABLE IF NOT EXISTS `movietypegroup` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(128) NOT NULL,
  `Color` varchar(7) NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Modified` (`Modified`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.oldids
CREATE TABLE IF NOT EXISTS `oldids` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.program
CREATE TABLE IF NOT EXISTS `program` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Deleted` tinyint(1) NOT NULL DEFAULT 0,
  `ChannelId` bigint(20) NOT NULL,
  `EpisodeId` bigint(20) NOT NULL,
  `StartDate` datetime NOT NULL,
  `StopDate` datetime NOT NULL,
  `IsRepeat` tinyint(1) NOT NULL DEFAULT 0,
  `IsLive` tinyint(1) NOT NULL DEFAULT 0,
  `IsRecommended` tinyint(1) NOT NULL DEFAULT 0,
  `PorthuId` bigint(20) NOT NULL DEFAULT 0,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `ChannelId` (`ChannelId`),
  KEY `EpisodeId` (`EpisodeId`),
  KEY `StartDate` (`StartDate`),
  KEY `StopDate` (`StopDate`),
  KEY `IsRepeat` (`IsRepeat`),
  KEY `PorthuId` (`PorthuId`),
  KEY `Modified` (`Modified`),
  KEY `Deleted` (`Deleted`),
  KEY `IsLive` (`IsLive`)
) ENGINE=InnoDB AUTO_INCREMENT=1574749 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.programrelated
CREATE TABLE IF NOT EXISTS `programrelated` (
  `ProgramId` bigint(20) NOT NULL,
  `OtherProgramId` bigint(20) NOT NULL,
  `Type` tinyint(4) NOT NULL,
  UNIQUE KEY `ProgramId` (`ProgramId`,`OtherProgramId`),
  KEY `OtherProgramId` (`OtherProgramId`),
  KEY `Type` (`Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.recording
CREATE TABLE IF NOT EXISTS `recording` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProgramId` bigint(20) NOT NULL,
  `UserId` varchar(36) NOT NULL,
  `MachineId` varchar(36) NOT NULL,
  `RecordingState` varchar(32) NOT NULL,
  `StateText` text DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ProgramId` (`ProgramId`),
  KEY `RecordingState` (`RecordingState`),
  KEY `UserId` (`UserId`),
  KEY `MachineId` (`MachineId`)
) ENGINE=InnoDB AUTO_INCREMENT=108082 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.region
CREATE TABLE IF NOT EXISTS `region` (
  `Id` varchar(3) NOT NULL,
  `Name` varchar(64) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.session
CREATE TABLE IF NOT EXISTS `session` (
  `Id` varchar(36) NOT NULL,
  `UserId` varchar(36) NOT NULL,
  `DeviceId` bigint(20) DEFAULT NULL,
  `LangId` varchar(3) DEFAULT NULL,
  `RegionId` varchar(3) DEFAULT NULL,
  `CreatedAt` datetime NOT NULL,
  `AccessedAt` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `UserId` (`UserId`),
  KEY `CreatedAt` (`CreatedAt`),
  KEY `AccessedAt` (`AccessedAt`),
  KEY `DeviceId` (`DeviceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.tuner
CREATE TABLE IF NOT EXISTS `tuner` (
  `Id` varchar(36) NOT NULL,
  `MachineId` varchar(36) NOT NULL,
  `ClientTunerData` mediumblob DEFAULT NULL,
  `FriendlyName` varchar(128) DEFAULT NULL,
  `DisplayName` varchar(192) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `MachineId` (`MachineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.tunerequest
CREATE TABLE IF NOT EXISTS `tunerequest` (
  `PackageId` bigint(20) NOT NULL,
  `ChannelId` bigint(20) NOT NULL DEFAULT 0,
  `Frequency` bigint(20) NOT NULL,
  `VideoStandard` int(11) NOT NULL DEFAULT 0,
  `IFECMethod` enum('Viterbi','RS_204_188','LDPC','BCH','RS_147_130') DEFAULT NULL,
  `IFECRate` enum('1_2','2_3','3_4','3_5','4_5','5_6','5_11','7_8','1_4','1_3','2_5','6_7','8_9','9_10') DEFAULT NULL,
  `OFECMethod` enum('Viterbi','RS_204_188','LDPC','BCH','RS_147_130') DEFAULT NULL,
  `OFECRate` enum('1_2','2_3','3_4','3_5','4_5','5_6','5_11','7_8','1_4','1_3','2_5','6_7','8_9','9_10') DEFAULT NULL,
  `Modulation` enum('16QAM','32QAM','64QAM','80QAM','96QAM','112QAM','128QAM','160QAM','192QAM','224QAM','256QAM','320QAM','384QAM','448QAM','512QAM','640QAM','768QAM','896QAM','1024QAM','QPSK','BPSK','OQPSK','8VSB','16VSB','ANALOG_AMPLITUDE','ANALOG_FREQUENCY','8PSK','RF','16APSK','32APSK','NBC_QPSK','NBC_8PSK','DIRECTV','ISDB_T_TMCC','ISDB_S_TMCC') DEFAULT NULL,
  `SymbolRate` int(11) NOT NULL DEFAULT 0,
  `Polarisation` enum('LINEAR_H','LINEAR_V','CIRCULAR_L','CIRCULAR_R') DEFAULT NULL,
  `LNBSource` tinyint(4) NOT NULL DEFAULT 0,
  `SpectralInversion` enum('Automatic','Normal','Inverted') DEFAULT NULL,
  `Bandwidth` int(11) NOT NULL DEFAULT 0,
  `LPIFECMethod` enum('Viterbi','RS_204_188','LDPC','BCH','RS_147_130') DEFAULT NULL,
  `LPIFECRate` enum('1_2','2_3','3_4','3_5','4_5','5_6','5_11','7_8','1_4','1_3','2_5','6_7','8_9','9_10') DEFAULT NULL,
  `HAlpha` int(11) NOT NULL DEFAULT 0,
  `Guard` int(11) NOT NULL DEFAULT 0,
  `TransmissionMode` int(11) NOT NULL DEFAULT 0,
  `OtherFrequencyInUse` tinyint(1) NOT NULL DEFAULT 0,
  `Path` varchar(512) DEFAULT NULL,
  KEY `PackageId` (`PackageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.tunerequestpackage
CREATE TABLE IF NOT EXISTS `tunerequestpackage` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Type` enum('Analog','DVB-S','DVB-T','DVB-C') NOT NULL,
  `Provider` varchar(32) NOT NULL,
  `Name` varchar(128) NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16069 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.tunerequestregion
CREATE TABLE IF NOT EXISTS `tunerequestregion` (
  `PackageId` bigint(20) NOT NULL,
  `RegionId` varchar(3) NOT NULL,
  UNIQUE KEY `PackageId` (`PackageId`,`RegionId`),
  KEY `RegionId` (`RegionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.tvstat
CREATE TABLE IF NOT EXISTS `tvstat` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` varchar(36) NOT NULL,
  `ChannelId` bigint(20) NOT NULL,
  `ProgramId` bigint(20) NOT NULL,
  `Start` datetime NOT NULL,
  `Stop` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `UserId` (`UserId`),
  KEY `ChannelId` (`ChannelId`),
  KEY `Start` (`Start`),
  KEY `Stop` (`Stop`),
  KEY `ProgramId` (`ProgramId`)
) ENGINE=InnoDB AUTO_INCREMENT=7889 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.user
CREATE TABLE IF NOT EXISTS `user` (
  `Id` varchar(36) NOT NULL,
  `ParentId` varchar(36) DEFAULT NULL,
  `Username` varchar(32) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Email` varchar(64) NOT NULL,
  `FirstName` varchar(32) DEFAULT NULL,
  `LastName` varchar(32) DEFAULT NULL,
  `BillingName` varchar(64) DEFAULT NULL,
  `BillingLastName` varchar(32) DEFAULT NULL,
  `BillingEmail` varchar(64) DEFAULT NULL,
  `BillingCompanyName` varchar(64) DEFAULT NULL,
  `Country` varchar(3) DEFAULT NULL,
  `City` varchar(64) DEFAULT NULL,
  `Address` varchar(64) DEFAULT NULL,
  `StreetNumber` varchar(16) DEFAULT NULL,
  `PostalCode` varchar(32) DEFAULT NULL,
  `PhoneNumber` varchar(32) DEFAULT NULL,
  `TaxNumber` varchar(16) DEFAULT NULL,
  `Gender` enum('M','F') DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `HomesysBeginUpdate` datetime DEFAULT NULL,
  `HomesysUpdate` datetime DEFAULT NULL,
  `HomesysVersion` varchar(32) DEFAULT NULL,
  `HomesysActivity` tinyint(4) NOT NULL DEFAULT 0,
  `LastSeen` datetime DEFAULT NULL,
  `LastSeenBefore` datetime DEFAULT NULL,
  `LastIP` varchar(16) DEFAULT NULL,
  `Lang` varchar(3) DEFAULT NULL,
  `LastTipId` bigint(20) DEFAULT NULL,
  `Guest` tinyint(1) NOT NULL DEFAULT 0,
  `ParentalAge` tinyint(4) NOT NULL DEFAULT 0,
  `UserIsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Username` (`Username`),
  KEY `Password` (`Password`),
  KEY `LastIP` (`LastIP`),
  KEY `HomesysActivity` (`HomesysActivity`),
  KEY `LastTipId` (`LastTipId`),
  KEY `ParentId` (`ParentId`)
) ENGINE=InnoDB AUTO_INCREMENT=136785 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.useragent
CREATE TABLE IF NOT EXISTS `useragent` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` text NOT NULL,
  `NameHash` varchar(32) DEFAULT NULL,
  `RequestCount` bigint(20) NOT NULL DEFAULT 0,
  `AcceptEncoding` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `NameHash` (`NameHash`)
) ENGINE=InnoDB AUTO_INCREMENT=13705 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for table homesyslite.userdevice
CREATE TABLE IF NOT EXISTS `userdevice` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` varchar(36) NOT NULL,
  `DeviceId` bigint(20) NOT NULL,
  `FirstSeen` datetime NOT NULL,
  `LastSeen` datetime NOT NULL,
  `VodAuthAt` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UserId_2` (`UserId`,`DeviceId`),
  KEY `UserId` (`UserId`),
  KEY `DeviceId` (`DeviceId`)
) ENGINE=InnoDB AUTO_INCREMENT=137688 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.

-- Dumping structure for view homesyslite.devicelist
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `devicelist`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `devicelist` AS select `t2`.`UserId` AS `userid`,`t3`.`Username` AS `username`,`t2`.`DeviceId` AS `deviceid`,`t1`.`System` AS `system`,`t1`.`Brand` AS `brand`,`t1`.`Model` AS `model`,`t1`.`Serial` AS `serial`,`t2`.`FirstSeen` AS `firstseen`,`t2`.`LastSeen` AS `lastseen`,`t2`.`VodAuthAt` AS `vodauthat` from ((`device` `t1` join `userdevice` `t2` on(`t2`.`DeviceId` = `t1`.`Id`)) join `user` `t3` on(`t3`.`Id` = `t2`.`UserId`)) ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
